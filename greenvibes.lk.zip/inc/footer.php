<footer>
	<p>Copyright © 2021 Greenvibes Technologies</p>
  <ul>
    <li><a href="https://fb.com/greenvibeslk"><i class="fab fa-facebook-f"></i></a></li>
    <li><a href="https://twitter.com/greenvibeslk"><i class="fab fa-twitter"></i></a></li>
    <li><a href="https://www.instagram.com/greenvibeslk/"><i class="fab fa-instagram"></i></a></li>
    <li><a href="https://api.whatsapp.com/send/?phone=%2B94768623177&text&app_absent=0"><i class="fab fa-whatsapp"></i></a></li>
    <li><a href="tel:+94768623177"><i class="fa fa-phone"></i></a></li>
  </ul>
</footer>


  <!-- responsive -->
<script>
    var navLinks = document.getElementById("navLinks");
    
    function showMenu(){
        navLinks.style.right = "0";
    }
    function hideMenu(){
        navLinks.style.right = "-200px";
    }
</script>
</body>
</html>