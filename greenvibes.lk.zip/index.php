<style type=text/css> .header {
    background-image: linear-gradient(rgba(4,9,30,0.7),rgba(4,9,30,0.7)),url(img/home.jpg);}
</style>

<?php $title = 'Home - '; ?>
<?php require_once('inc/header.php'); ?>
  <div class="text-box">
        <h1>Make it simple. But significant</h1>
        <p>ShareTheMeal is a crowdfunding smartphone application to fight global hunger through the United Nations World Food Programme (WFP).</p>
        <a href="news/index.php" class="visit-btn">Visit us</a>
        </div>
    </section>
<body>
<section class="content">
  


</section>
<hr>
<br>
<h3 id="latest">LATEST NEWS</h3>
<?php require_once('inc/latest-post.php'); ?>

<?php require_once('inc/footer.php'); ?>
 