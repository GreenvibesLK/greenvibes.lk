Remote Operated Diagnostic Analyzer (RDA)-

D.M.W.Dhanushka Bandara donated a Remote Operated Diagnostic Analyzer (RDA) to IDH and Homagama Hospital. 
RDA gives access to monitor patients remotely from doctors and facilitates a number of doctors to diagnose the patient through visual conference. Blood pressure could monitor with 95% accuracy. Saturation can also be monitored without intact of doctors. 
This app installed in mobile phones of doctors', permits to monitor patients while the doctor is at any corner of the world. Dialogue between patient and doctor is easily made.