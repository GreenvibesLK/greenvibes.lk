<style type=text/css> .header {
    background-image: linear-gradient(rgba(4,9,30,0.7),rgba(4,9,30,0.7)),url(img/contact.gif);}
</style>

<?php $title = 'Contact - '; ?>
<?php require_once('inc/header.php'); ?>
  <div class="text-box">
        <h1>Let's Chat</h1>
        <p>ShareTheMeal is a crowdfunding smartphone application to fight global hunger through the United Nations World Food Programme (WFP).</p>
        <a href="" class="visit-btn">Visit us</a>
        </div>
    </section>
<body>











</body>
</html>
<?php require_once('inc/footer.php'); ?>